<?php
header("Content-Type: application/json");

include 'conn.php';

$sql = "SELECT `name` FROM `events`";
$result = $conn->query($sql);

if (!$result) {
    echo "Error: " . $conn->error;
    exit;
}

$options = []; // Initialize the $options array

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $options[] = $row['name']; // Populate the $options array with 'name'
    }
} else {
    echo "No names found.";
}

// Close the database connection
$conn->close();

// Return options as JSON response
echo json_encode($options);


?>
