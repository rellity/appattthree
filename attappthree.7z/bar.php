<?php
require 'vendor/autoload.php'; // Include barcode generation library

use Picqer\Barcode\BarcodeGeneratorPNG;

$value = $_GET['value']; // Get barcode value from query parameter

$barcodeGenerator = new BarcodeGeneratorPNG();
$barcodeImage = $barcodeGenerator->getBarcode($value, BarcodeGeneratorPNG::TYPE_CODE_128);

header('Content-Type: image/png'); // Set the content type to image/png
echo $barcodeImage; // Output the barcode image
?>
