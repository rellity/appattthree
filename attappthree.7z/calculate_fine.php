<?php
header("Content-Type: application/json");

include 'conn.php';

$absentTotal = 0;
$studentID = $_GET['id'];

$events = [
    'holliday-1-wed-nov-4-2023' => false,
    'mondaysevent' => true
];

foreach ($events as $eventName => $isPresent) {
    if (!$isPresent) {
        $priceSql = "SELECT price FROM `events` WHERE name = '$eventName'";
        $priceResult = $conn->query($priceSql);

        if ($priceResult->num_rows > 0) {
            $row = $priceResult->fetch_assoc();
            $absentTotal += (int) $row['price'];
        }
    }
}

$response = ['total_fine' => strval($absentTotal)];
echo json_encode($response);

$conn->close();
?>
