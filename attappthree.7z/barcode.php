<?php
require 'vendor/autoload.php'; // Include barcode generation library

use Picqer\Barcode\BarcodeGeneratorPNG;

$value = $_GET['value']; // Get barcode value from query parameter

$barcodeGenerator = new BarcodeGeneratorPNG();
$barcodeImage = base64_encode($barcodeGenerator->getBarcode($value, BarcodeGeneratorPNG::TYPE_CODE_128));

$response = [
    'barcodeImage' => $barcodeImage,
    'text' => $value
];

header('Content-Type: application/json'); // Set the content type to JSON
echo json_encode($response); // Output the JSON response
?>

