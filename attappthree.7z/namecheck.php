<?php
header("Content-Type: application/json");

include 'conn.php';

$stuid = $_GET['studentId'];

// Select student details
$sql = "SELECT * FROM user WHERE stuid = '$stuid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $studentData = array(
        "name" => $row["name"],

    );

    echo json_encode(array("success" => true, "studentInfo" => $studentData));
} else {
    echo json_encode(array("success" => false, "error" => "Student not found"));
}
?>