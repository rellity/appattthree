<?php
header("Content-Type: application/json");

include 'conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET["id"])) {
        $id = $_GET["id"];

        $sql = "SELECT * FROM user WHERE stuid = '$id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $studentData = [
                'name' => $row['name'],
                'stuid' => $row['stuid'],
            ];
            echo json_encode($studentData);
        } else {
            echo json_encode(["error" => "Student not found"]);
        }

        $conn->close();
    } else {
        echo json_encode(["error" => "Missing or invalid parameters"]);
    }
} else {
    echo json_encode(["error" => "Unsupported request method"]);
}
?>
