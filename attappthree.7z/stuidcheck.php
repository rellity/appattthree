<?php
header("Content-Type: application/json");

include 'conn.php';


$stuid = $_GET['stuid'];

$sql = "SELECT COUNT(*) AS count FROM user WHERE stuid = '$stuid'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $count = $row["count"];

    if ($count > 0) {
        $response = array("valid" => true);
    } else {
        $response = array("valid" => false);
    }

    echo json_encode($response);
} else {
    echo json_encode(array("valid" => false, "error" => "No results or database error"));
}
?>
