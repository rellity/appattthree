<?php
header("Content-Type: application/json");

include 'conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET["scannedData"]) && isset($_GET["selectedTable"])) {
        $scannedData = $_GET["scannedData"];
        $selectedTable = $_GET["selectedTable"];

        // check if it exist
        $checkSql = "SELECT * FROM $selectedTable WHERE idno = '$scannedData'";
        $result = $conn->query($checkSql);

        if ($result && $result->num_rows > 0) {
            // error return
            echo json_encode(["error" => "Data already exists"]);
        } else {
            // goes ahead and add
            $insertSql = "INSERT INTO $selectedTable (idno, login, logout, logbyin, logbyout) 
                        VALUES ('$scannedData', CURRENT_TIMESTAMP, NULL, NULL, NULL)";

            if ($conn->query($insertSql) === TRUE) {
                echo json_encode(["success" => "Data inserted successfully"]);
            } else {
                echo json_encode(["error" => $conn->error]);
            }
        }

        $conn->close();
    } else {
        echo json_encode(["error" => "Missing or invalid parameters"]);
    }
} else {
    echo json_encode(["error" => "Unsupported request method"]);
}
?>
