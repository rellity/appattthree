<?php
header("Content-Type: application/json");
include 'conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET["value"])) {
        $tableName = $_GET["value"];

        $sql = "SELECT * FROM events WHERE name = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $tableName);
        $stmt->execute();
        
        $result = $stmt->get_result();

        if ($result === false) {
            echo json_encode(["error" => $conn->error]);
        } else {
            $options = [];
            while ($row = $result->fetch_assoc()) {
                $options[] = $row;
            }
            echo json_encode($options);
        }
    } else {
        echo json_encode(["error" => "No 'value' parameter provided :/"]);
    }
} else {
    echo json_encode(["error" => "Unsupported request method"]);
}

?>
