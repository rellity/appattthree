<?php
header("Content-Type: application/json");

include 'conn.php';

// Fetch event names and their corresponding table names
$sql = "SELECT name FROM events";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $events = array();
    while ($row = $result->fetch_assoc()) {
        $events[] = array(
            "name" => $row['name'],
        );
    }

    $response = array();

    // Sample student ID, replace this with the actual ID you want to check
    $studentID = $_GET['id']; // Replace this with the student ID you're checking
    
    foreach ($events as $event) {
        $tableName = $event['name'];
        $sql = "SELECT * FROM `$tableName` WHERE idno = '$studentID'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $response[$event['name']] = true;
        } else {
            $response[$event['name']] = false;
        }
    }

    echo json_encode($response);
} else {
    echo json_encode(array("error" => "No events found."));
}

$conn->close();
?>
